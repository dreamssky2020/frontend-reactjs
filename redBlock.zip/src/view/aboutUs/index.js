import React, { Component } from 'react'
import Header from '../../components/common/Header/TopHeader';
import JoinForm from '../../components/homePage/JoinForm';
import Footer from '../../components/common/Footer';
import AboutUsContent from '../../components/aboutUsPage/AboutUsContent';

export class index extends Component {
    render() {
        return (
            <div>
                <Header />

                <AboutUsContent />

                <JoinForm />
                
                <Footer />
            </div>
        )
    }
}

export default index
