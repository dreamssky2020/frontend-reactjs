import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Select from "react-select";
import IconButton from '@material-ui/core/IconButton';
import issuerKycData from '../../../data/issuerKycData.json'
import '../../../css/dashboard/issuerKyc.css'

const options = [
    { value: "edit", label: "Edit" },
    { value: "delete", label: "Delete" },
    { value: "statistics", label: "Statistics" },
    { value: "asset detail", label: "Asset detail" },
  ];

export class index extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }
    componentDidMount(){
        this.props.selectLeftSidebar('kycState');

        this.setState({tableDatas: issuerKycData});
        this.setState({originData: issuerKycData});
        var temp = [];
        if(issuerKycData.length>10)
            temp = issuerKycData.slice(0, 10);
        else
            temp = issuerKycData.slice(0, issuerKycData.length);
        this.setState({showDatas: temp});
    }


    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }

    render() {
        return (
            <div className="issuer-kyc-container animation-effect">
                <div className="title-btn-body">
                    <p className="dashboard-sub-title dark-blue">Issuer KYC/AML</p>
                    <Link to={'/dashboard/kyc-id-verify'} className="link-style">
                        <button className="add-officer-btn red-btn-hover">Add Officer</button>
                    </Link>
                </div>
                <div className="issuer-kyc-table-container dashboard-card">
                    <div className="issuer-title-searchbox-contain">
                        <p className="dark-blue">Officer</p>
                        <div>
                            <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                            <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                                <i className="fa fa-search"></i>
                            </IconButton>
                        </div>
                    </div>
                    <table className="issuer-kyc-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Creadted Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.showDatas.map((data, i) => 
                            <tr key={i}>
                                <td>{data.name}</td>
                                <td>{data.email}</td>
                                <td>{data.phone}</td>
                                <td>{data.status === "1" ? (<span className="light-green-color">Verified</span>):(<span className="light-pink-color">Non-Verified</span>)}</td>
                                <td>{data.created_date}</td>
                                {/* <td>
                                    <IconButton  className="double-check-icon-btn" component="label">
                                        <img src={'../../assets/icons/double-check.png'} alt="double check png"/>
                                    </IconButton>
                                    <IconButton component="label">
                                        <img src={'../../assets/icons/pencil.png'} alt="pencil png" />
                                    </IconButton>
                                    <IconButton component="label">
                                        <img src={'../../assets/icons/trash.png'} alt="trash png" />
                                    </IconButton > 
                                </td> */}
                                <td style={{paddingRight: "15px"}}>
                                    <Select options={options}  defaultValue={{ label: "Edit", value: 0 }}/>
                                </td>
                            </tr>
                            )}
                        </tbody>
                    </table>
                    </div>

                    <div className="table-num-arrow-main">
                        {this.state.showDatas.length === 0 && (
                        <p>no data</p>
                        )}
                    </div>

            </div>
        )
    }
}

export default index
