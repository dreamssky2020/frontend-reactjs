import React, { Component } from 'react'
import Select from "react-select";
import ActiveIcon from '@material-ui/icons/CheckCircleOutlineOutlined'
import ClosedIcon from '@material-ui/icons/GpsOff'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import ExpandLessIcon from '@material-ui/icons/ExpandLess'

import '../../../css/dashboard/mainDashboard.css'

const options = [
    { value: "edit", label: "Edit" },
    { value: "delete", label: "Delete" },
    { value: "statistics", label: "Statistics" },
    { value: "asset detail", label: "Asset detail" },
  ];

export class index extends Component {

    componentDidMount(){
        this.props.selectLeftSidebar('dashboardState');
    }

    handleDashboard = () => {
        const { history } = this.props;
        history.push({ pathname: '/dashboard/redblock'});
    }

    render() {
        return (
            <div className="main-dashboard-container animation-effect">
                <p className="dashboard-sub-title dark-blue">Assets</p>
                <div className="main-asset-table-contain">
                    <table className="main-asset-table">
                        <thead>
                            <tr>
                                <th>Assests Name</th>
                                <th>Type</th>
                                <th>Category</th>
                                <th>Authorized Total</th>
                                <th>Status</th>
                                <th></th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="table-sub-header" onClick={()=>this.handleDashboard()}>
                                <td>Redbloack <ExpandMoreIcon className="expand-icon"/></td>
                                <td>Preferred</td>
                                <td>Real Estate</td>
                                <td>1000000</td>
                                <td>
                                    <div className="table-td-active"><ActiveIcon className="acitve-icon"/>Active</div>
                                </td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr className="table-sub-item">
                                <td>Round Name</td>
                                <td>Open Date</td>
                                <td>Close Date</td>
                                <td>Total Unit</td>
                                <td>Status</td>
                                <td>Price Per Unit</td>
                                <td>Action</td>
                            </tr>
                            <tr>
                                <td>Seed Fund</td>
                                <td>02/02/2020</td>
                                <td>02/03/2020</td>
                                <td>500000</td>
                                <td>
                                    <div className="table-td-active table-td-closed"><ClosedIcon className="acitve-icon closed-icon"/>Closed</div>
                                </td>
                                <td>$1</td>
                                {/* <td>
                                    <i className="fa fa-file-text-o"></i>
                                    <i className="fa fa-trash"></i>
                                </td> */}
                                <td>
                                    <Select options={options}  defaultValue={{ label: "Edit", value: 0 }}/>
                                </td>
                            </tr>
                            <tr>
                                <td>Seed Fund</td>
                                <td>02/02/2020</td>
                                <td>02/03/2020</td>
                                <td>500000</td>
                                <td>
                                    <div className="table-td-active"><ActiveIcon className="acitve-icon"/>Active</div>
                                </td>
                                <td>$1</td>
                                {/* <td>
                                    <i className="fa fa-file-text-o"></i>
                                    <i className="fa fa-trash"></i>
                                </td> */}
                                <td>
                                    <Select options={options}  defaultValue={{ label: "Edit", value: 0 }}/>
                                </td>
                            </tr>
                            <tr className="table-sub-header">
                                <td>Redbloack <ExpandLessIcon className="expand-icon"/></td>
                                <td>Preferred</td>
                                <td>Real Estate</td>
                                <td>1000000</td>
                                <td>
                                    <div className="table-td-active"><ActiveIcon className="acitve-icon"/>Active</div>
                                </td>
                                <td></td>
                                <td></td>
                            </tr>                            
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default index
