import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Select from 'react-select'
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from '@material-ui/core/IconButton';
import investorWhitelistData from '../../../data/investorWhitelistData.json'
import '../../../css/dashboard/distribution.css'

const options1 = [
    {value: "VISA", label: "VISA"},
    {value: "Paypal", label: "Paypal"},
    {value: "Bitcoin", label: "Bitcoin"},
];
const options2 = [
    {value: "1 Week", label: "1 Week"},
    {value: "1 Month", label: "1 Month"},
    {value: "1 Year", label: "1 Year"},
];


export class Distribution extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }
    componentDidMount(){

        this.props.selectLeftSidebar('dashboardState');

        this.setState({tableDatas: investorWhitelistData});
        this.setState({originData: investorWhitelistData});
        var temp = [];
        if(investorWhitelistData.length>10)
            temp = investorWhitelistData.slice(0, 10);
        else
            temp = investorWhitelistData.slice(0, investorWhitelistData.length);
        this.setState({showDatas: temp});
    }


    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                if(object.name.toLocaleLowerCase().indexOf(value)>-1) return true;
                if(object.wallet_address.toLocaleLowerCase().indexOf(value)>-1) return true;
                if(object.unit.toLocaleLowerCase().indexOf(value)>-1) return true;
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }
    render() {
        return (
            <div className="distribution-container animation-effect">
                <p className="dashboard-sub-title dark-blue">Distribution</p>
                <div className="row distribution-body dashboard-card">
                    <div className="col-lg-5">
                        <div className="form-group dashboard-form-group">
                            <label>Amount</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Payment</label>
                            <Select options={options1} placeholder="" className="payment-select-contain"/>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Dividend Date</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Frequency</label>
                            <Select options={options2} placeholder="" className="payment-select-contain"/>
                        </div>
                        <div className="payment-submit-btn">
                            <button className="round-submit-btn">Submit</button>
                        </div>
                    </div>
                    <div className="col-lg-7 distribution-table-wrapper">
                        <div className="distribution-investor-title-searchbox-contain">
                            <p className="dark-blue">Investors</p>
                            <div>
                                <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                                <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                                    <i className="fa fa-search"></i>
                                </IconButton>
                            </div>
                        </div>
                        <div className="distribution-investor-table-container">
                            <table className="distribution-investor-table">
                                <thead>
                                    <tr>
                                        <th>      
                                            <Checkbox
                                                className="checkbox-btn"
                                            />
                                            Name
                                        </th>
                                        <th>Wallet Address</th>
                                        <th>Unit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.showDatas.map((data, i) => 
                                    <tr key={i}>
                                        <td>
                                            <Checkbox
                                                className="checkbox-btn"
                                            />
                                            {data.name}
                                        </td>
                                        <td>{data.wallet_address}</td>
                                        <td>{data.unit}</td>
                                    </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div className="undo-btn-body">
                    <Link to={'/dashboard/assets'} className="link-style">
                        <IconButton component="label" className="undo-btn">
                            <i className="fa fa-undo"></i>
                        </IconButton>
                    </Link>
                </div>
            </div>
        )
    }
}

export default Distribution
