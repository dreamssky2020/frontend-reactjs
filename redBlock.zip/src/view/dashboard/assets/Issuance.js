import React, { Component } from 'react'
import Stepper from './Stepper';
import Select from "react-select";
import { Link } from 'react-router-dom'
import IconButton from '@material-ui/core/IconButton';

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import ZIndex from 'react-z-index';
ZIndex.setVar('DatePicker', 400)



const steps = [{title: 'Assets Offering'}, {title: 'Upload Documents'}, {title: 'Issue Digital Assets'},]

// select and components  start

  const options1 = [
    { value: "chocolate", label: "Chocolate" },
    { value: "strawberry", label: "Strawberry" },
    { value: "vanilla", label: "Vanilla" },
  ];
  const options2 = [
    { value: "chocolate", label: "Chocolate" },
    { value: "strawberry", label: "Strawberry" },
    { value: "vanilla", label: "Vanilla" },
  ];

// selet option end
export class Issuance extends Component {
    constructor(props) {
        super(props);

        this.state = {
            activeStep: 1,
            startDate:new Date(),
        }
    }

    componentDidMount(){

        this.props.selectLeftSidebar('dashboardState');
    }

    handleOnClickStepper = (step) => {
        this.setState({activeStep: step});
    }

    handleOnNextClick = () => {
        let nextStep = this.state.activeStep + 1;
        this.setState({activeStep: nextStep})
    }

    handleOnClickBack = () => {
        let prevStep = this.state.activeStep - 1;
        this.setState({activeStep:prevStep})
    }
    render() {
        const{startDate}=this.state;

        return (
            <div className="animation-effect">
                <Stepper 
                    steps={steps} 
                    activeStep={this.state.activeStep}
                    onSelect={this.handleOnClickStepper}
                    showNumber={false} 
                />
                <div className="iss-contents">  
{/* //------------------------------------------------------ assets offering start------------------------------------------------------------  */}
                    {
                        this.state.activeStep === 1 ? <div> 
                            <div className="assetting-offering-content">
                                <div className="col-xl-12"> 
                                    <div className="row">
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group">
                                                <label>Type</label>
                                                <Select options={options1} />
                                            </div>                                                                                  
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group">
                                                <label>Unite Type</label>
                                                <Select options={options2} />
                                            </div>                                                                                  
                                        </div>
                                        <div className="col-lg-12 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Name &nbsp;<span className="exclamation-circle-icon"><strong>&#x21;</strong></span></label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-xl-6 col-md-12 offering-content-row">
                                            <div className="">
                                                <label className="offering-row-label">Asset Sold As:</label>
                                                <div className="row container responsive-row-remove">
                                                    <div className="form-check col-lg-6 col-md-6 col-sm-6 col-xs-4 offring-checkform-row">
                                                        <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck1" />
                                                        <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Price Per Unite/Share</label>
                                                    </div> 
                                                    <div className="input-group col-lg-6 col-md-6 col-sm-6 col-xs-6">                                        
                                                        <div className="input-group-prepend ">
                                                            <span className="input-group-text offering-inputgroup-pre-span"><i className="fa fa-usd" aria-hidden="true"></i></span>
                                                        </div>                               
                                                        <input type="text" className="form-control offering-input" name="#" />
                                                    </div>
                                                    <div className="form-check offring-checkform-row small-top-space">
                                                        <input type="checkbox" className="form-check-input offering-checkbox " id="exampleCheck1" />
                                                        <label className="form-check-label offering-check-label ceremonial-label" htmlFor="exampleCheck1">Email ceremonial to investors when cetificates to investors when security is issued? <span className="exclamation-circle-icon"><strong>&#x21;</strong></span></label>
                                                    </div> 
                                                </div>                              
                                            </div>                                                       
                                        </div>
                                        <div className="col-xl-6 col-md-12 offering-content-row responsive-top-space">
                                            <div className="form-group">
                                                <label>The regulatory exemption the securities are to be offered under</label>
                                                <Select options={options2} />
                                            </div>                                                                                  
                                        </div>
                                        <div className="row col-xl-12 col-md-12 offering-content-row" /> 
                                        <div className="col-xl-6 col-md-12 offering-content-row">
                                            <div className="">
                                                <label className="offering-row-label">Are there any restrictions on investor's ability to transfer ownership to others?</label>
                                                <div className="row container">
                                                    <div className="form-check col-lg-2 col-md-4 col-sm-4 offring-checkform-row">
                                                        <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                        <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Yes</label>
                                                    </div>
                                                    <div className="form-check col-lg-2 col-md-4 col-sm-4 offring-checkform-row">
                                                        <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck3" />
                                                        <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">No</label>
                                                    </div>
                                                </div>                                      
                                            </div>                                                       
                                        </div>
                                        <div className="col-xl-6 col-md-12 offering-content-row">
                                            <div className="responsive-top-space">
                                                <label className="offering-row-label">Is the issuer's business in any way related Cannabis, gambling, aduit or firearms?</label>
                                                <div className="row container">
                                                    <div className="form-check col-lg-2 col-md-4 col-sm-4 offring-checkform-row">
                                                        <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                        <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Yes</label>
                                                    </div>
                                                    <div className="form-check col-lg-2 col-md-4 col-sm-4 offring-checkform-row">
                                                        <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck3" />
                                                        <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">No</label>
                                                    </div>
                                                </div>                                      
                                            </div>                                                       
                                        </div>
                                        <div className="col-xl-6 col-md-12 offering-content-row">
                                            <div className="calander-move">
                                                <label>Start at</label>
                                                <div className="input-group">                                        
                                                    <div className="input-group-prepend ">
                                                        <span className="input-group-text offering-inputgroup-pre-span"><i className="fa fa-calendar-o" aria-hidden="true"></i></span>
                                                    </div>                               
                                                    <input type="text" className="form-control offering-input" name="#" />
                                                </div>
                                                <div className="calendar-selete-pic">
                                                    <DatePicker
                                                        selected={startDate}
                                                        onChange={date => this.setState({startDate:date})}
                                                        showTimeSelect
                                                        timeFormat="HH:mm"
                                                        timeIntervals={15}
                                                        timeCaption="time"
                                                        dateFormat="MMMM d, yyyy h:mm aa"
                                                        style={{zIndex: '100'}} 
                                                    />
                                                </div>                                                 
                                            </div>                                                                           
                                        </div>
                                        <div className="col-xl-6 col-md-12 offering-content-row small-bottom-space">
                                            <div className="calander-move">
                                                <label>End at</label>
                                                <div className="input-group">                                        
                                                    <div className="input-group-prepend ">
                                                        <span className="input-group-text offering-inputgroup-pre-span"><i className="fa fa-calendar-o" aria-hidden="true"></i></span>
                                                    </div>                               
                                                    <input type="text" className="form-control offering-input" name="#" />
                                                </div>
                                                <div className="calendar-selete-pic">
                                                    <DatePicker
                                                        selected={startDate}
                                                        onChange={date => this.setState(date)}
                                                        showTimeSelect
                                                        timeFormat="HH:mm"
                                                        timeIntervals={15}
                                                        timeCaption="time"
                                                        dateFormat="MMMM d, yyyy h:mm aa"
                                                        style={{zIndex: '100'}}                                                         
                                                    />
                                                </div>                                                 
                                            </div>                                                                           
                                        </div>
                                        <div className="col-xl-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Maximum investor amount allowed? &nbsp;<span className="exclamation-circle-icon"><strong>&#x21;</strong></span></label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="row col-lg-12 col-md-12 offering-content-row" /> 
                                        <div className="col-xl-6 col-md-12 offering-content-row">
                                            <div className="">
                                                <label className="offering-row-label">Accept the following types of investors</label>
                                                <div className="container">
                                                    <div className="offring-check-group top-small-space">
                                                        <div className="form-check offring-checkform-row">
                                                            <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                            <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Allow accredited investors?</label>
                                                        </div>
                                                        <div className="form-check offring-checkform-row">
                                                            <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                            <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Allow non-accredited investors?</label>
                                                        </div>
                                                        <div className="form-check offring-checkform-row">
                                                            <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                            <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Allow non-accredited investors?</label>
                                                        </div>
                                                        <div className="form-check offring-checkform-row left-space">
                                                            <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                            <label className="form-check-label offering-check-label " htmlFor="exampleCheck1">Allow non-accredited investors?</label>
                                                        </div>
                                                        <div className="form-check offring-checkform-row">
                                                            <input type="checkbox" className="form-check-input offering-checkbox" id="exampleCheck2" />
                                                            <label className="form-check-label offering-check-label" htmlFor="exampleCheck1">Allow non-accredited investors?</label>
                                                        </div>
                                                    </div>
                                                </div>                                      
                                            </div>                                                       
                                        </div>
                                        <div className="row col-lg-12 col-md-12 offering-content-row" />
                                        <div className="col-lg-6 col-md-12 offering-content-row top-space">
                                            <div className="form-group ">
                                                <label>Round Type:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row top-space">
                                            <div className="form-group ">
                                                <label>Round Size:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Raised to date:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Minimum investment:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Target Minimum:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="row col-lg-12 col-md-12 offering-content-row" />
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <h5 className="offring-middle-title"> Key Terms</h5>
                                        </div>
                                        <div className="row col-lg-12 col-md-12 offering-content-row" />
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Security Type:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Share Price:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Raised to date:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Option Pool:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="col-lg-6 col-md-12 offering-content-row">
                                            <div className="form-group ">
                                                <label>Liquidation Preference:</label>
                                                <input type="text" className="form-control offering-input"  required="" />
                                            </div>                                                       
                                        </div>
                                        <div className="row col-lg-12 col-md-12 offering-content-row" />
                                        <div className="col-lg-12 col-md-12 offering-content-row responsicve-reverce-top-space">
                                            <div className="form-group top-space text-center bottom-space">
                                                <button type="button" className="company-profile-sub-btn issu-content-next-button red-btn-hover" onClick={this.state.activeStep === steps.length ? null : this.handleOnNextClick}>Next</button>
                                            </div>                                                       
                                        </div>
                                    </div>     
                                </div>
                            </div>
                        </div> :
                        
        // ---------------------------------------------------------upload document start--------------------------------------------------------------------
                        this.state.activeStep === 2 ? <div>
                            <div className="row document-upload-content">
                                <div className="col-lg-4 col-md-4 form-group">
                                    <label>Liquidation Preference:</label>
                                    <div className="document-upload-colume">
                                       <div className="form-group upload-part">
                                            <div >
                                                <IconButton component="label" className="upload-icon-btn">
                                                    <i className="fa fa-cloud-upload"></i>
                                                    <input
                                                        type="file"
                                                        name="media"
                                                        // accept="audio/*,video/*,image/*"
                                                        style={{ display: "none" }}
                                                    />
                                                </IconButton>
                                            </div>
                                            <label>Upload Media</label>
                                        </div> 
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-4 form-group">
                                    <label>Liquidation Preference:</label>
                                    <div className="document-upload-colume">
                                       <div className="form-group upload-part">
                                            <div >
                                            <IconButton component="label" className="upload-icon-btn">
                                                <i className="fa fa-cloud-upload"></i>
                                                <input
                                                    type="file"
                                                    name="media"
                                                    // accept="audio/*,video/*,image/*"
                                                    style={{ display: "none" }}
                                                />
                                            </IconButton>
                                            </div>
                                            <label>Upload Media</label>
                                        </div> 
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-4 form-group">
                                    <label>Liquidation Preference:</label>
                                    <div className="document-upload-colume">
                                       <div className="form-group upload-part">
                                            <div >
                                            <IconButton component="label" className="upload-icon-btn">
                                                <i className="fa fa-cloud-upload"></i>
                                                <input
                                                    type="file"
                                                    name="media"
                                                    // accept="audio/*,video/*,image/*"
                                                    style={{ display: "none" }}
                                                />
                                            </IconButton>
                                            </div>
                                            <label>Upload Media</label>
                                        </div> 
                                    </div>
                                </div>
                                <div className="col-l2 top-space" />
                                <div className="col-l2 top-space" />
                                <div className="col-l2 top-space" />

                                <div className="col-lg-12 col-md-12 offering-content-row">
                                    <div className="form-group top-space text-center">
                                        <button type="button" className="company-profile-sub-btn issu-content-next-button red-btn-hover" onClick={this.state.activeStep === steps.length ? null : this.handleOnNextClick}>Next</button>
                                    </div>                                                       
                                </div>
                            </div>
                        </div> :

        //-----------------------------------------------------------issue disigtal start----------------------------------------------------------------------               
                        <div>
                            <div className="iss-disigtal-content">
                                <div className="email-confrim-main application-sub issue-disigtal-step3">
                                    <div className="email-box-main iss-check-ico">
                                        <i className="fa fa-check-circle"></i>
                                    </div>
                                    <div className="disital-content-title">
                                        <h3 className="dark-blue"><strong>Your Application has been submitted</strong></h3>
                                        <p>
                                            You'll received a notification once your application is approved
                                        </p>
                                    </div>
                                    <div className="disital-content-button-section">
                                        <Link to={'/dashboard/redblock'} className="link-style">
                                            <button className="distion-sub-btn">Back</button>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    }
                </div>
{/* ------------------------------------------------------------------------issue content end --------------------------------------------------------------------------- */}
            </div>
        )
    }
}

export default Issuance
