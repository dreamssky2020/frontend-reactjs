import React, { Component } from 'react'
import { Line } from 'react-chartjs-2'
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips'
import {
  CircularProgressbar,
  buildStyles
} from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { Link } from 'react-router-dom'
import IconButton from '@material-ui/core/IconButton';

import CommentStatusData from '../../../data/commentStatusData.json'
import MoreVert from '@material-ui/icons/MoreVert'

import '../../../css/dashboard/dashboardRedbloack.css'
import TabContent from './TabContent'


var data1 = [1200, 900, 850, 700, 750, 600, 650, 500, 550, 400, 300];
var data2 = [0, 200, 250, 300, 280, 400, 420, 600, 750, 800, 900];

const mainChart = {
  labels: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'],

  datasets: [
    {
      label: 'Fund receiving 1',
      backgroundColor: 'transparent',
      borderColor: '#FFABAB',
      pointHoverBackgroundColor: '#fff',
      borderWidth: 2,
      data: data1,
    },
    {
      label: 'Fund receiving 2',
      backgroundColor: 'transparent',
      borderColor: '#4BD78C',
      pointHoverBackgroundColor: '#fff',
      borderWidth: 2,
      data: data2,
    },
  ],
};

const mainChartOpts = {
  tooltips: {
    enabled: true,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function(tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor }
      }
    }
  },
  maintainAspectRatio: false,
  legend: {
    display: false,
  },
  scales: {
    xAxes: [
      {
        gridLines: {
          drawOnChartArea: false,
        },
        display: false,
      }],
    yAxes: [
      {
        ticks: {
          beginAtZero: true,
          maxTicksLimit: 5,
          stepSize: Math.ceil(300),
          max: 1200,
          callback: function(value, index, values) {
                        return '$' + value;
            }
        },
      }],
  },
  elements: {
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    },
  },
};


export class DashboardRedbloack extends Component {
    
    componentDidMount(){
        this.props.selectLeftSidebar('dashboardState');
    }

    render() {
        return (
            <div className="dashboard-redbloack-contain animation-effect">
                <div className="row dashboard-asset-items-wrapper">
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      <Link to={'/dashboard/invest-white-list'} className="link-style">
                        <div className="assets-item-contain green-color">
                            <div className="assets-item-img-body green-color-round">
                                <img src={'../../assets/icons/contract.png'} alt="contract png"/>
                            </div>
                            <p className="mb-0">Investor Whitelist</p>
                        </div>
                      </Link>
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      <Link to={'/dashboard/documents'} className="link-style">
                        <div className="assets-item-contain red-color">
                            <div className="assets-item-img-body red-color-round">
                                <img src={'../../assets/icons/document.png'} alt="contract png"/>
                            </div>
                            <p className="mb-0">Documents</p>
                        </div>
                      </Link>
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      <Link to={'/dashboard/issuance'} className="link-style">
                          <div className="assets-item-contain sky-color">
                              <div className="assets-item-img-body sky-color-round">
                                  <img src={'../../assets/icons/message.png'} alt="contract png"/>
                              </div>
                              <p className="mb-0">Issuance</p>
                          </div>
                      </Link>
                    </div>
                    
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      <Link to={'/dashboard/distribution'} className="link-style">
                          <div className="assets-item-contain purple-color">
                              <div className="assets-item-img-body purple-color-round">
                                  <img src={'../../assets/icons/wallet.png'} alt="contract png"/>
                              </div>
                              <p className="mb-0">Distribution</p>
                          </div>
                      </Link>
                    </div>
                </div>

                {/* chart and progress bar */}
                <div className="row">
                    <div className="col-lg-8">
                      <div className="statistics-chart-contain dashboard-card">
                        <div className="row">
                          <div className="col-xl-6 col-lg-12 flex-vertical-align chart-title-description">
                            <p className="asset-sub-title">Statistics</p>
                            <p className="dark-blue mb-0">Investment Updates (Funding Process)</p>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 keyword-title-wrapper flex-vertical-align">
                              <div>
                                <i className="fa fa-circle green-color"></i>
                                <span className="ml-2 green-color chart-keyword-title">Funding receiving</span>
                              </div>
                              <div>
                                <i className="fa fa-circle light-red-color"></i>
                                <span className="ml-2 light-red-color chart-keyword-title">Funding receiving</span>
                              </div>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 flex-vertical-align chart-month-select">
                              <select className="form-control">
                                  <option value={1}>Jan</option>
                                  <option value={2}>Feb</option>
                                  <option value={3}>Mar</option>
                                  <option value={4}>Apr</option>
                                  <option value={5}>May</option>
                                  <option value={6}>Jun</option>
                                  <option value={7}>Jul</option>
                                  <option value={8}>Aug</option>
                                  <option value={9}>Sep</option>
                                  <option value={9}>Oct</option>
                                  <option value={9}>Nov</option>
                                  <option value={9}>Dec</option>
                                </select>
                          </div>
                        </div>

                        <div className="chart-wrapper">
                          <Line data={mainChart} options={mainChartOpts} className="line-chart-body"/>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-4">
                        <div className="circle-progress-bar-main dashboard-card">
                            <div className="circle-progress-bar-contain">
                              <CircularProgressbar
                                value={70}
                                text={`70%`}
                                styles={buildStyles({
                                  rotation: 0.5,
                                  textColor: "#475F77",
                                  pathColor: "#4BD78C",
                                })}
                              />
                            </div>
                          <div className="circle-progress-description">
                              <div className="flex-vertical-align">
                                <span className="light-dark-color">Raised</span>
                                <h5 className="green-color"><strong>$700</strong></h5>
                              </div>
                              <div className="flex-vertical-align left-right-both-border">
                                <span className="light-dark-color">Need</span>
                                <h5 className="light-red-color"><strong>$500</strong></h5>
                              </div>
                              <div className="flex-vertical-align">
                                <span className="light-dark-color">Raised</span>
                                <h5 className="dark-blue"><strong>$700</strong></h5>
                              </div>
                          </div>
                        </div>
                    </div>
                </div>

                {/* Tab and status */}
                <div className="row tab-status-container">
                  <div className="col-xl-8 col-lg-12">
                      <TabContent />
                  </div>
                  <div className="col-xl-4 col-lg-12 dashboard-status-contain">
                    <div className="d-flex justify-content-between">
                      <div><p className="asset-sub-title">Status</p></div>
                      <div className="align-self-center to-details-page">
                        <Link to={'/dashboard/details'}> 
                          Details
                        </Link>
                      </div>
                    </div>
                      {
                        CommentStatusData.map((obj, i) => 
                          <div key={i} className="comment-status-main">
                            <div>
                              <p className="comment-status-date">{obj.date}</p>
                              <p className="comment-status-time">Invest {obj.time}</p>
                            </div>
                            <div>
                              <p className="comment-status-date">{obj.name}</p>
                              <p className="comment-status-time">{obj.value} 
                                &nbsp;Tokens
                              </p>
                            </div>
                            <div>
                              <IconButton className="moreVert-icon-btn">
                                <MoreVert className="moreVert-icon"/>
                              </IconButton>
                            </div>
                          </div>
                        )
                      }
                  </div>
                </div>

                <div className="undo-btn-body">
                    <Link to={'/dashboard/assets'} className="link-style">
                        <IconButton component="label" className="undo-btn">
                            <i className="fa fa-undo"></i>
                        </IconButton>
                    </Link>
                </div>

            </div>
        )
    }
}

export default DashboardRedbloack
