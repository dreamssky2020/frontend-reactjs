import React from 'react';
import '../../../css/dashboard/issuance.css'

export default class Stepper extends React.Component {
    

    render() {
        const { steps, showNumber, activeStep, onSelect } = this.props;
        const lastIndexOfSteps = steps.length - 1;
        return(
            <div className="issue-contain">
                <React.Fragment>
                    <h2 className="windows-title">Issuance</h2>
                    <div className="stepper-container">
                        {steps.map((step, index) => {
                            return(
                                <React.Fragment key={index}>
                                    <div className="stepper-item">                                        
                                        <div className="stepper-item-outer" onClick={onSelect.bind(null,index+1)}>
                                            <div className={`stepper-item-inner ${activeStep === (index+1) ? 'stepper-item-inner-active' : (index + 1) < activeStep ? 'stepper-item-inner-completed' : 'stepper-item-inner-future'}`}>  {showNumber && index + 1}{index + 1}</div>
                                        </div>
                                        <span className={`stepper-title ${activeStep === (index+1) ? 'stepper-title-active' : (index + 1) < activeStep ? 'stepper-title-completed':''}`}> {step.title} </span>
                                    </div>
                                    {lastIndexOfSteps === index ? '' :  
                                        <div className={`stepper-item-outer ${activeStep === (index+1) ? 'stepper-item-outer-active' : (index + 1) < activeStep ? 'stepper-item-outer-completed' : 'stepper-item-outer-future'}`}></div>
                                    }
                                </React.Fragment>
                            )
                        })}
                    </div>
                </React.Fragment>
            </div>
        )
    }
}