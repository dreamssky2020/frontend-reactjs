import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import IconButton from '@material-ui/core/IconButton';
import investorWhitelistData from '../../../data/investorWhitelistData.json'
import '../../../css/dashboard/investorWhitelist.css'


export class investWhiteList extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }
    componentDidMount(){

        this.props.selectLeftSidebar('dashboardState');

        this.setState({tableDatas: investorWhitelistData});
        this.setState({originData: investorWhitelistData});
        var temp = [];
        if(investorWhitelistData.length>10)
            temp = investorWhitelistData.slice(0, 10);
        else
            temp = investorWhitelistData.slice(0, investorWhitelistData.length);
        this.setState({showDatas: temp});
    }


    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }

    render() {
        return (
            <div className="investor-whitelist-container animation-effect">
                <div className="investor-title-searchbox-contain">
                    <p className="dashboard-sub-title dark-blue">Investor WhiteList</p>
                    <div>
                        <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Wallet Address/Email"></input>
                        <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                            <i className="fa fa-search"></i>
                        </IconButton>
                    </div>
                </div>
                <div className="investor-whitelist-table-container">
                    <table className="investor-whitelist-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Country</th>
                                <th>Type</th>
                                <th>Wallet Address</th>
                                <th>Email</th>
                                <th>KYC Status</th>
                                <th>accreditation</th>
                                <th>Unit</th>
                                <th>Percentage</th>
                                <th>Creadted Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.showDatas.map((data, i) => 
                            <tr key={i}>
                                <td>{data.name}</td>
                                <td>{data.country}</td>
                                <td>{data.type}</td>
                                <td>{data.wallet_address}</td>
                                <td>{data.email}</td>
                                <td>{data.kyc_status}</td>
                                <td>{data.accreditation}</td>
                                <td>{data.unit}</td>
                                <td>{data.percentage}%</td>
                                <td>{data.created_date}</td>
                            </tr>
                            )}
                        </tbody>
                    </table>
                    </div>

                    <div className="table-num-arrow-main">
                        {this.state.showDatas.length>0 ? (
                            <p>Showing  {this.state.currentPage*10 + 1} - {this.state.tableDatas.length>10 ? this.state.currentPage*10 + 10: this.state.tableDatas.length} of {this.state.tableDatas.length}</p>
                            ):(<p>no data</p>)}
                        <div>
                            <i className="fa fa-long-arrow-left" onClick={()=>this.handlePagePrevious()}></i>
                            <i className="fa fa-long-arrow-right" onClick={()=>this.handlePageNext()}></i>
                        </div>
                    </div>

                    <div className="undo-btn-body">
                    <Link to={'/dashboard/assets'} className="link-style">
                        <IconButton component="label" className="undo-btn">
                            <i className="fa fa-undo"></i>
                        </IconButton>
                    </Link>
                </div>
            </div>
        )
    }
}

export default investWhiteList
