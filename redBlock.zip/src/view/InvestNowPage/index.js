import React, { Component } from 'react'
import TopHeader from '../../components/common/Header/TopHeader';
import JoinForm from '../../components/homePage/JoinForm';
import Footer from '../../components/common/Footer';
import InvestNowPageContent from '../../components/InvestNowPage/InvestNowPageContent';

export class index extends Component {
    render() {
        return (
            <div>
                <TopHeader />

                <InvestNowPageContent />
                
                <JoinForm />

                <Footer />
            </div>
        )
    }
}

export default index
