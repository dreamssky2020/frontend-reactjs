import React, { Component } from 'react'
import TopHeader from '../../components/common/Header/TopHeader';
import JoinForm from '../../components/homePage/JoinForm';
import Footer from '../../components/common/Footer';
import AssetsDetailContent from '../../components/assetsDetailPage/AssetsDetailContent';

export class index extends Component {
    render() {
        return (
            <div>
                <TopHeader />

                <AssetsDetailContent />

                <JoinForm />
                
                <Footer />
            </div>
        )
    }
}

export default index
