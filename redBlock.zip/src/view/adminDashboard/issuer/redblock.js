import React, { Component } from 'react';
import TabList from './TabList';
import CompanyProfileDocument from './companyProfileDocument';
import adminIssuerData from '../../../data/adminIssuerData.json';
import issuerRedblockData from '../../../data/issuerRedblockData.json';
import companyProfileData from '../../../data/issureCompanyProfileData.json';
import issuerKycData from '../../../data/issuerKycData.json'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import '../../../css/dashboard/account.css';
import Select from "react-select";
import IconButton from '@material-ui/core/IconButton';
import SpaceBarIcon from '@material-ui/icons/SpaceBar';
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';

const options = [
    { value: "verify", label: "Verify" },
    { value: "delete", label: "Delete" },
    { value: "statistics", label: "Statistics" },
    { value: "asset detail", label: "Asset detail" },
  ];

export default class Account extends Component {
    constructor(props){
        super(props);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDetailDatas: [],
            showDatas: [],
            search_value: "",
            issuerRedblockDatas: [],
            companyProfile: [],
        }
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    componentDidMount(){
        this.props.selectLeftSidebar('issuerState');

        this.setState({issuerRedblockDatas: issuerRedblockData});
        this.setState({tableDatas: adminIssuerData});
        this.setState({originData: adminIssuerData});
        this.setState({companyProfile: companyProfileData});
        var temp = [];
        if(adminIssuerData.length>10)
            temp = adminIssuerData.slice(0, 10);
        else
            temp = adminIssuerData.slice(0, adminIssuerData.length);
        this.setState({showDetailDatas: temp});

        this.setState({tableDatas: issuerKycData});
        this.setState({originData: issuerKycData});
        if(issuerKycData.length>10)
            temp = issuerKycData.slice(0, 10);
        else
            temp = issuerKycData.slice(0, issuerKycData.length);
        this.setState({showDatas: temp});
        
    }

    
    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }


    render() {
        return (
            <div className="up  animation-effect">
                <p className="admin-issuer-redblock-title dark-blue"><strong>Issuer </strong>/ Redblock</p>
                <TabList>
                    {/*@@@@@@@@@@@@@@@@@@@@@@@@@@@ Detail section  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */}
                    <div label="Detail" className="tab-content">
                        <div className="admin-issuer-detail-tab-content">
                            <div className="admin-issuer-redblock-table-container main-asset-table-contain" style={{margin: '1px'}}>
                                <table className="main-asset-table">
                                    <thead>
                                        <tr>
                                            <th>Company Name</th>
                                            <th>Country</th>
                                            <th>Email</th>
                                            <th>Password</th>
                                            <th>Phone</th>
                                            <th>Company Profile</th>
                                            <th>KYC Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    {this.state.showDetailDatas.map((data, i) => 
                                        <tr key={i}>
                                            <td>{data.company_name}</td>
                                            <td>{data.country}</td>
                                            <td>{data.email}</td>
                                            <td>{data.password}</td>
                                            <td>{data.phone}</td>
                                            <td>{data.company_profile}</td>
                                            <td>{data.kyc_status}</td>
                                        </tr>
                                        )}
                                    
                                    </tbody>
                                </table>
                            </div>
                            <div className="d-flex align-items-center one-item-admin-redblock-tr" style={{background:"#FFABAB", color:"#D74B4B"}}>
                                <div>SL</div>
                                <div>Asset Name</div>
                                <div>Type</div>
                                <div>Category</div>
                            </div>

                            <div className="d-flex align-items-center one-item-admin-redblock-tr" style={{background:"#D6D6D6", color:"#5E5E5E"}}>
                                <div>01</div>
                                <div>Redbloack <ExpandMoreIcon className="expand-icon"/></div>
                                <div>Preferred Equity</div>
                                <div>Real Estate</div>
                            </div>

                            <div className="admin-issuer-redblock-data-table main-asset-table-contain" style={{margin: '1px'}}>
                                <table className="main-asset-table">
                                    <thead>
                                        <tr>
                                            <th>Round Name</th>
                                            <th>Open Date</th>
                                            <th>Close Date</th>
                                            <th>Total Unit</th>
                                            <th>Status</th>
                                            <th>Price Per Unit</th>
                                            <th>Funding Portal</th>
                                            <th>Issuance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    {this.state.issuerRedblockDatas.map((data, i) => 
                                        <tr key={i}>
                                            <td>{data.round_name}</td>
                                            <td>{data.open_date}</td>
                                            <td>{data.close_date}</td>
                                            <td>{data.total_unit}</td>
                                            <td>
                                                {data.status === 'Active'?(<div className="active-container"><img src={"../assets/images/check.png"} alt="green check png"/><span>Active</span></div>):
                                                (<div className="pending-container"><img src={"../assets/images/info.png"} alt=" red info png"/><span>Pending</span></div>
                                                )}
                                            </td>
                                            <td>${data.price_per_unit}</td>
                                            <td><img src={"../assets/images/note-check.png"} alt=" green note-check png"/></td>
                                            <td>
                                                {data.status === 'Active'?(<img src={"../assets/images/note-check.png"} alt="green note-check png"/>):(<img src={"../assets/images/red-note-check.png"} alt=" red note-check png"/>
                                                )}</td>
                                        </tr>
                                        )}
                                    
                                    </tbody>
                                </table>
                            </div>

                            <div className="d-flex align-items-center one-item-admin-redblock-tr" style={{background:"#D6D6D6", color:"#5E5E5E"}}>
                                <div>02</div>
                                <div>Square <ExpandLessIcon className="expand-icon"/></div>
                                <div>Preferred Equity</div>
                                <div>Real Estate</div>
                            </div>
                        </div>
                    </div>
                    {/*@@@@@@@@@@@@@@@@@@@@@@ Company profilesection @@@@@@@@@@@@@@@@@@@@@@@ */}
                    <div label="Company Profile" className="tab-content">
                        <div className="company-profile">
                            <div className="container">
                                <div className="documation my-4">
                                    <div className="title">documation</div>
                                    { this.state.companyProfile.map( data => 
                                            <CompanyProfileDocument key={data.id} data={data} />
                                    )}
                                </div>

                                <div className="address my-4">
                                    <div className="form-group-row">
                                        <h4>Address</h4>
                                    </div>
                                    <div className="row address-row">
                                        <div className="col-sm-12 col-md-12 col-lg-7">
                                            <div className="form-group profile-row">
                                                <label>Street Address</label>
                                                <div className="input-group">                                        
                                                    <div className="input-group-prepend ">
                                                        <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                    </div>                               
                                                    <input type="text" className="form-control prepend-input" name="#"
                                                    placeholder="4606 Michael Street " />
                                                </div>
                                            </div>
                                            <div className="form-group profile-row">
                                                <label>Apartment, suite or unit number</label>
                                                <input type="text" className="form-control prepend-input unit-number" placeholder="B#5"/>
                                            </div>
                                            <div className="row form-group profile-row address-items">
                                                <div className="col-md-6 address-item1">
                                                    <label>City</label>
                                                    <div className="input-group">
                                                        <div className="input-group-prepend ">
                                                            <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                        </div>                               
                                                        <input type="text" className="form-control prepend-input" name="#" placeholder="Sugar Land" />
                                                    </div>
                                                </div>
                                                
                                                <div className="col-md-6 address-item2">
                                                    <label>Zipcode</label>
                                                    <div className="input-group">
                                                        <div className="input-group-prepend ">
                                                            <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                        </div>                               
                                                        <input type="text" className="form-control prepend-input" name="#" placeholder="77478" />
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div className="row form-group profile-row address-items">
                                                <div className="col-md-6 address-item1">
                                                    <label>State</label>
                                                    <div className="input-group">
                                                        <div className="input-group-prepend ">
                                                            <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                        </div>                               
                                                        <input type="text" className="form-control prepend-input" name="#" placeholder="Texas"/>
                                                    </div>
                                                </div>
                                                
                                                <div className="col-md-6 address-item2">
                                                    <label>Country</label>
                                                    <div className="input-group-prepend"> 
                                                        <input type="text" className="w-100 form-control prepend-input" name="#" placeholder="USA"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-md-12 col-lg-5"></div>
                                    </div>
                                </div>  
                            </div>         
                            <div className="button-group">
                                <div className="d-flex justify-content-center">
                                    <div><button className="btn decline">Decline</button></div>
                                    <div><button className="btn approved">Approved</button></div>
                                </div>
                            </div>
                        </div>      
                    </div>     


                  {/* ---- kyc ----- */}
                    <div label="KYC" className="tab-content">
                        <div className="animation-effect admin-kyc-container">

                            <div className="issuer-kyc-table-container">
                                <div className="issuer-title-searchbox-contain">
                                    <p className="dark-blue">Officer</p>
                                    <div>
                                        <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                                        <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                                            <i className="fa fa-search"></i>
                                        </IconButton>
                                    </div>
                                </div>
                                <table className="issuer-kyc-table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Status</th>
                                            <th>Creadted Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.state.showDatas.map((data, i) => 
                                        <tr key={i}>
                                            <td>{data.name}</td>
                                            <td>{data.email}</td>
                                            <td>{data.phone}</td>
                                            <td>{data.status === "1" ? (<span className="light-green-color">Verified</span>):(<span className="light-pink-color">Non-Verified</span>)}</td>
                                            <td>{data.created_date}</td>
             
                                            <td style={{paddingRight: "15px"}}>
                                                <Select options={options}  defaultValue={{ label: "Verify", value: 0 }}/>
                                            </td>
                                        </tr>
                                        )}
                                    </tbody>
                                </table>
                                </div>

                                <div className="table-num-arrow-main">
                                    {this.state.showDetailDatas.length === 0 && (
                                    <p>no data</p>
                                    )}
                                </div>

                        </div>
                    </div>

                        
                    {/* --- Funding Portal --- */}
                    <div label="Funding Portal" className="tab-content">
                        <div className="admin-issuer-funding-portal-container">
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-6">
                                        <p className="funding-title">Asset Info</p>
                                        <p className="subtitle">Asset Name</p>
                                        <p className="subtitle-desc">Incoporate_doc_2020</p>
                                        <p className="subtitle">Target Raise</p>
                                        <p className="subtitle-desc">Incoporate_doc_2020</p>
                                        <p className="subtitle">Price Per Unit</p>
                                        <p className="subtitle-desc">$1.00</p>
                                        <p className="subtitle">Minimun Investment</p>
                                        <p className="subtitle-desc">$1.00</p>
                                        <p className="subtitle">Asset Website</p>
                                        <p className="subtitle-desc">WWW.assets.com</p>
                                        <p className="subtitle">Country</p>
                                        <p className="subtitle-desc">USA</p>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="external-text-link-container">
                                            <div className="external-link-container">
                                                <p>http://youtubecapital.com</p>
                                                <img src={"../assets/icons/external-link.png"} alt="external link png" />
                                            </div>
                                            <p className="dark-blue">YouTube Channel Link</p>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <p className="funding-title mt-5">Highlight</p>
                                    <p className="subtitle">Why invest us?</p>
                                    <p className="subtitle-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                    ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
                                    no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
                                     invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                                      justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
                                      consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
                                    </p>

                                    <p className="funding-title mt-5">Overview</p>
                                    <p className="subtitle-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                    ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
                                    no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
                                     invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                                      justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
                                      consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
                                    </p>

                                    <p className="funding-title mt-5">Description</p>
                                    <p className="subtitle">Why invest us?</p>
                                    <p className="subtitle-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                    ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
                                    no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
                                     invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                                      justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
                                      consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
                                    </p>
                                </div>

                                <div className="pitch-deck-pdf-download-main">
                                    <p className="funding-title">Pitch Deck(PDF)</p>
                                    <div className="pitch-deck-pdf-download-container">
                                        <div>
                                            Pitch_dec_2020.pdf
                                        </div>
                                        <div className="download-button-container">
                                            <button className="btn">Download 
                                                <div className="icons" >
                                                    <div><ArrowDownwardIcon/></div>
                                                    <div><SpaceBarIcon /></div>
                                                </div> 
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <p className="funding-title mt-5">Risk Factors & Disclosure</p>
                                    <p className="subtitle-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                    ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
                                    no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
                                     invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                                      justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
                                      consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
                                    </p>
                                    <p className="subtitle-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                    ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
                                    no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
                                     invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                                      justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
                                      consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
                                    </p>
                                    <p className="subtitle-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                    ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
                                    no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
                                     invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                                      justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
                                      consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,
                                    </p>
                                </div>

                                <div className="button-group mt-5">
                                    <div className="d-flex justify-content-center">
                                        <div><button className="btn decline">Decline</button></div>
                                        <div><button className="btn approved">Approved</button></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div label="Issuance" className="tab-content">
                        Issuance
                    </div>
                </TabList>
                <br/>
                <br/>
                <br/>
                <br/>
            </div>
            
        )
    }
}

