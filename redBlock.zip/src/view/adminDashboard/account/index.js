import React, { Component } from 'react';
import '../../../css/adminDashboard/account.css';

export class index extends Component {
    componentDidMount(){
        this.props.selectLeftSidebar('accountState');
    }
    render() {
        return (
            <div className="admin-account-container dashboard-card">
                <div className="col-lg-12 col-md-12 form-group-row">
                    <div className="form-group">
                        <label>Current Password</label>
                        <input type="text" className="form-control account-setting-input"  required="" />
                    </div>                                                       
                </div>

                <div className="col-lg-12 col-md-12 form-group-row">
                    <div className="form-group">
                        <label>New Password</label>
                        <input type="text" className="form-control account-setting-input"  required="" />
                    </div>  
                </div>

                <div className="col-lg-12 col-md-12 form-group-row">
                    <div className="form-group">
                        <label>Re-enter New Password</label>
                        <input type="text" className="form-control account-setting-input"  required="" />
                    </div>  
                </div>
                <div className="col-lg-12 col-md-12 form-group-row">
                    <button type="button" className="account-setting-save-btn form-group round-btn">Save</button>
                </div>
            </div>     
        )
    }
}

export default index
