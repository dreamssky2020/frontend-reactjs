import React, { Component } from 'react'
import IconButton from '@material-ui/core/IconButton';
import Select from "react-select";
import investorDashboardData from '../../../data/investorDashboard.json'

import '../../../css/dashboard/mainDashboard.css'
import '../../../css/investorDashboard/assets.css'

const options = [
    { value: "edit", label: "Edit" },
    { value: "delete", label: "Delete" },
    { value: "statistics", label: "Statistics" },
    { value: "asset detail", label: "Asset detail" },
  ];
export class index extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }

    componentDidMount(){
        this.props.selectLeftSidebar('dashboardState');

        this.setState({tableDatas: investorDashboardData});
        this.setState({originData: investorDashboardData});
        var temp = [];
        if(investorDashboardData.length>10)
            temp = investorDashboardData.slice(0, 10);
        else
            temp = investorDashboardData.slice(0, investorDashboardData.length);
        this.setState({showDatas: temp});
    }

    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }

    handleDashboard = () => {
        const { history } = this.props;
        history.push({ pathname: '/investor-dashboard/redblock'});
    }

    render() {
        return (
            <div className="main-dashboard-container animation-effect investor-assets-container">
                <div className="flex-align-justify investor-search-main-body">
                    <p className="in-dashboard-sub-title dark-blue mb-0">Assets</p>
                    <div className="investor-search-wrapper">
                        <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                        <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                            <i className="fa fa-search"></i>
                        </IconButton>
                    </div>
                </div>
                <div className="main-asset-table-contain">
                    <table className="main-asset-table">
                        <thead>
                            <tr>
                                <th>Offering Name</th>
                                <th>Issuer</th>
                                <th>Round</th>
                                <th>Business Sector</th>
                                <th>Exemption</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Price per Unit</th>
                                <th>Created Date</th>
                                <th>Closed Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        {this.state.showDatas.map((data, i) => 
                            <tr key={i} onClick={() => this.handleDashboard()}>
                                <td>{data.offering_name}</td>
                                <td>{data.issuer}</td>
                                <td>{data.round}</td>
                                <td>{data.business_sector}</td>
                                <td>{data.exemption}</td>
                                <td>{data.type}</td>
                                <td>{data.amount}</td>
                                <td>${data.price_per_unit}</td>
                                <td>{data.created_date}%</td>
                                <td>{data.closed_date}</td>
                                {/* <td><i className="fa fa-file-text-o"></i></td> */}
                                <td>
                                    <Select options={options}  defaultValue={{ label: "Edit", value: 0 }}/>
                                </td>
                            </tr>
                            )}
                           
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default index
