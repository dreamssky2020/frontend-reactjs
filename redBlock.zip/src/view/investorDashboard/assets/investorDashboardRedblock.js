import React, { Component } from 'react'
import { Line } from 'react-chartjs-2'
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips'
// import {
//   CircularProgressbar,
//   buildStyles
// } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { Link } from 'react-router-dom'
import IconButton from '@material-ui/core/IconButton';
import GetAppIcon from '@material-ui/icons/GetApp';
import documentsData from '../../../data/documentsData.json'


import '../../../css/investorDashboard/investorDashboard.css'
var data3 = [0, 230,300,480,660,850,1119,850,870,1200,900,950,900,1000,1200,1300,1325,1350,1375,1400];

const mainChart = {
  labels: ['1', '2','3','4' ,'5','6','7','8','10','11','12','13','14','15','16','17','18','19','20'],

  datasets: [
    {
      label: 'Fund receiving 2',
      backgroundColor: 'transparent',
      borderColor: '#4BD78C',
      pointHoverBackgroundColor: '#fff',
      borderWidth: 2,
      data: data3,
    },
  ],
};

const mainChartOpts = {
  tooltips: {
    enabled: true,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function(tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor }
      }
    }
  },
  maintainAspectRatio: false,
  legend: {
    display: false,
  },
  scales: {
    xAxes: [
      {
        gridLines: {
          drawOnChartArea: false,
        },
        display: false,
      }],
    yAxes: [
      {
        ticks: {
          beginAtZero: true,
          maxTicksLimit: 5,
          stepSize: Math.ceil(500),
          max: 2000,
          callback: function(value, index, values) {
                        return '$' + value;
            }
        },
      }],
  },
  elements: {
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    },
  },
};


export class DashboardRedbloack extends Component {

  constructor(props){
    super(props);
    this.state = {
        showDatas: [],
    }
  }

  componentDidMount(){
    this.props.selectLeftSidebar('dashboardState');
    this.setState({showDatas: documentsData});
  }

  


    render() {
        return (
            <div className="dashboard-redbloack-contain animation-effect">
                <div className="investor-page-title"> 
                  <h3><strong> Redledger: </strong> YourPosition</h3>
                </div>
                <div className="row dashboard-asset-items-wrapper">
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      {/* <Link to={'/dashboard/invest-white-list'} className="link-style"> */}
                        <div className="assets-item-contain green-color">
                            <div className="assets-item-img-body green-color-round">
                                <img src={'../../assets/icons/contract.png'} alt="contract png"/>
                            </div>
                            <div className = "assets-item-text-body"> 
                                <p className="mb-0 gray-color-text" >Number of Shares</p>
                                <p  className="mb-0">5000</p>
                            </div>
                        </div>
                      {/* </Link> */}
                    </div>                    
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      {/* <Link to={'/dashboard/issuance'} className="link-style"> */}
                          <div className="assets-item-contain sky-color">
                              <div className="assets-item-img-body sky-color-round dollar-image-size">
                                  <img src={'../../assets/icons/dollar.png'} alt="contract png"/>
                              </div>
                              <div className = "assets-item-text-body"> 
                                <p className="mb-0 gray-color-text" >Price Per Share </p>
                                <p  className="mb-0">$2.00</p>
                            </div>
                          </div>
                      {/* </Link> */}
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      {/* <Link to={'/dashboard/distribution'} className="link-style"> */}
                          <div className="assets-item-contain purple-color">
                              <div className="assets-item-img-body purple-color-round">
                                  <img src={'../../assets/icons/grayDocument.png'} alt="contract png"/>
                              </div>
                              <div className = "assets-item-text-body"> 
                                <p className="mb-0 gray-color-text" >Portfolio</p>
                                <p  className="mb-0">$1000</p>
                            </div>
                          </div>
                      {/* </Link> */}
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                      {/* <Link to={'/dashboard/documents'} className="link-style"> */}
                        <div className="assets-item-contain red-color">
                            <div className="assets-item-img-body red-color-round percent-image-size">
                                <img src={'../../assets/icons/percent.png'} alt="contract png"/>
                            </div>
                            <div className = "assets-item-text-body"> 
                                <p className="mb-0 gray-color-text" >Portfolio Diversity</p>
                                <p  className="mb-0">10%</p>
                            </div>
                        </div>
                      {/* </Link> */}
                    </div>
                    
                   
                </div>

                {/* chart and progress bar */}
                <div className="row">
                    <div className="col-lg-8">
                      <div className="statistics-chart-contain dashboard-card">
                        <div className="row chart-title-row">
                          <div className="col-xl-9 col-lg-6 col-sm-6 col-xs-6  chart-title-description statistic-body">
                            <p className="asset-sub-title">Statistics</p>
                          </div>
                          <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-6 flex-vertical-align chart-month-select">
                              <select className="form-control view-select">
                                  <option value={1}>this month</option>
                                  <option value={2}>three month</option>
                                  <option value={3}>this year</option>
                                </select>
                          </div>
                        </div>

                        <div className="chart-wrapper">
                          <Line data={mainChart} options={mainChartOpts} className="line-chart-body"/>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-4">
                        <div className="circle-progress-bar-main dashboard-card">
                            <div className="circle-progress-bar-contain finace-body">
                              <div className="finances-body green-color-round">
                                  <img src={'../../assets/icons/finances.png'} alt="finances"/>
                              </div>
                              <div className="finaces-total-amount">
                                <h1>$9587</h1>
                              </div>
                            </div>
                          <div className="circle-progress-description">
                              <div className="flex-vertical-align whight-blue-cell">
                                <span className="">Icrease</span>
                                <h5 className=""><strong>13%</strong></h5>
                              </div>
                              <div className="flex-vertical-align left-right-both-border green-cell">
                                <span className="light-dark-color">Total Profit</span>
                                <h5 className=""><strong>$500</strong></h5>
                              </div>
                              <div className="flex-vertical-align whight-red-cell">
                                <span className="">Download</span>
                                <h5 className=""><GetAppIcon /></h5>
                              </div>
                          </div>
                        </div>
                    </div>
                </div>

                {/* first offring detail */}
                <div className="detail-table-title row-space">
                  <h5>Offring Detail</h5>
                </div>
                <div  className="documents-whitelist-table-container">
                  <div className="offering-detail-data-fomart-table">
                      {/* header */}
                      <div className="col-lg-12 col-md-12 table-header-red offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 table-header-text ">Issuer</div>
                        <div className="col-lg-6 col-md-6 table-header-text ">Redblock Inc.</div>
                      </div>
                      {/* body */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Funding Round</div>
                        <div className="col-lg-6 col-md-6 ">Series A</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Asset</div>
                        <div className="col-lg-6 col-md-6 ">RedLedger</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Currency</div>
                        <div className="col-lg-6 col-md-6 ">USD</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Offering Type</div>
                        <div className="col-lg-6 col-md-6 ">Equity</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Type of Equity</div>
                        <div className="col-lg-6 col-md-6 ">Preferred</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Rights</div>
                        <div className="col-lg-6 col-md-6 ">Voting</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Exemption</div>
                        <div className="col-lg-6 col-md-6 ">Reg C 506 d</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Accreditation Required</div>
                        <div className="col-lg-6 col-md-6 ">Yes</div>
                      </div>
                          {/* space start */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 space-row">space</div>
                        <div className="col-lg-6 col-md-6 space-row">space</div>
                      </div>
                          {/* space end */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Company Maximum Raise</div>
                        <div className="col-lg-6 col-md-6 ">10000000</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Company Minimum Raise</div>
                        <div className="col-lg-6 col-md-6 ">1000000</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Investor Maximum Investment</div>
                        <div className="col-lg-6 col-md-6 ">10000</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Investor Minimum Investment</div>
                        <div className="col-lg-6 col-md-6 ">1000</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Price Per Unit</div>
                        <div className="col-lg-6 col-md-6 ">$1.00</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Total Unit Available</div>
                        <div className="col-lg-6 col-md-6 ">10000000</div>
                      </div>
                          {/* space start */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 space-row">space</div>
                        <div className="col-lg-6 col-md-6 space-row">space</div>
                      </div>
                          {/* space end */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Proposed Custody</div>
                        <div className="col-lg-6 col-md-6 ">Prime Trust</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Proposed Broker Dealer</div>
                        <div className="col-lg-6 col-md-6 ">Fidelity</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Proposed Transfer Agent</div>
                        <div className="col-lg-6 col-md-6 ">RedBlock Inc</div>
                      </div>
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 ">Proposed Secondary Market</div>
                        <div className="col-lg-6 col-md-6 ">Tzero</div>
                      </div>
                          {/* space start */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row">
                        <div className="col-lg-6 col-md-6 space-row">space</div>
                        <div className="col-lg-6 col-md-6 space-row">space</div>
                      </div>
                          {/* space end */}
                      <div className="col-lg-12 col-md-12 offering-detail-content-row final-row">
                        <div className="col-lg-6 col-md-6 max-content">Accept ESCROW</div>
                        <div className="col-lg-6 col-md-6 max-content">Wire Transfer/Check/BTC/ETH/USDT</div>
                      </div>
                    </div>
                  </div>
                {/* second offring detail */}
                <div className="detail-table-title row-space">
                  <h5>Offring Detail</h5>
                </div> 
                <div className="documents-whitelist-table-container">
                    <table className="documents-whitelist-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Files</th>
                                <th>Last Modified</th>
                                <th>Type</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.showDatas.map((data, i) => 
                            <tr key={i}>
                                <td className="folder-name-td">
                                    {/* <Link to={'/dashboard/funding-portal'} className="link-style"> */}
                                        <i className="fa fa-chevron-right"></i>
                                        <img src={'../../assets/icons/document.png'} alt="folder png"/>
                                        {data.name}
                                    {/* </Link> */}
                                </td>
                                <td>{data.number}</td>
                                <td>{data.modified}&nbsp;Hours ago</td>
                                <td>{data.type}</td>
                                <td>
                                    <IconButton component="label">
                                        <i className="fa fa-cloud-upload"></i>
                                        <input
                                        type="file"
                                        name="file"
                                        style={{ display: "none" }} />
                                    </IconButton>
                                </td>
                            </tr>
                            )}
                        </tbody>
                    </table>
                </div>
                <div className="investor-page-footer">
                  <p className="">Private Placement Memorandum</p>
                  <p className="">Subscription Agreement</p>
                  <p className="">Token Purchase Agreement</p>
                </div>





                <div className="undo-btn-body">
                    <Link to={'/investor-dashboard/assets'} className="link-style">
                        <IconButton component="label" className="undo-btn">
                            <i className="fa fa-undo"></i>
                        </IconButton>
                    </Link>
                </div>

            </div>
        )
    }
}

export default DashboardRedbloack
