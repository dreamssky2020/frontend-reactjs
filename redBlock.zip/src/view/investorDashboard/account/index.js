import React, { Component } from 'react';
import TabList from './AccountList';

import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';

import '../../../css/dashboard/account.css'

export default class Account extends Component {

    constructor(props){
        super(props);
        this.state = {
            emailConfirmState: false,
        }
    }

    componentDidMount(){
        this.props.selectLeftSidebar('accountState');
    }

    handleOpen = () => {
        this.setState({emailConfirmState: true});
    };
    
    handleClose = () => {
        this.setState({emailConfirmState: false});
    };

    render() {
        return (
            <div className="up  animation-effect">
                <TabList>
{/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ acccout setting section@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */}
                    <div label="Settings" className="tab-content">
                        <div className="col-12 setting-content">
                            <div className="col-xl-8 account-settings"> 
                                <div className="row account-contents">
                                <div className="col-lg-6 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>First Name</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                                                  
                                    </div>
                                    <div className="col-lg-6 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Last Name</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                       
                                    </div>
                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Nationality</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                       
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Email Address</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Asset Holder type</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Token Address</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>

                                    <div className="col-lg-12 col-md-12 d-flex justify-content-center form-group-row">
                                        <button type="button" className="account-setting-save-btn form-group round-btn">Save</button>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>

{/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Change password section@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */}                                        
                    <div label="Change Password" className="tab-content">
                        <div className="col-12 setting-content">
                            <div className="col-lg-5 chnagePassword-settings"> 
                                <div className="row account-contents">
                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Current Password</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                       
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>New Password</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Re-enter New Password</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>
                                    <div className="col-lg-12 col-md-12 d-flex justify-content-center form-group-row">
                                        <button type="button" className="account-setting-save-btn form-group round-btn">Save</button>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </TabList>

                <Modal
                    aria-labelledby="transition-modal-title"
                    aria-describedby="transition-modal-description"
                    className="email-confirm-modal"
                    open={this.state.emailConfirmState}
                    onClose={()=>this.handleClose()}
                    closeAfterTransition
                    BackdropComponent={Backdrop}
                    BackdropProps={{
                    timeout: 500,
                    }}
                >
                    <Fade in={this.state.emailConfirmState}>
                    <div className="email-confrim-main application-sub">
                        <div className="email-box-main">
                            <img src="../../images/tick.png" alt="tick png"/>
                        </div>
                        <div>
                            <h3 className="dark-blue"><strong>Your Application has been submitted</strong></h3>
                            <p>
                                You'll received a notification once your application is approved
                            </p>
                        </div><br></br><br></br><br></br>
                        <div>
                            <button className="round-lightred-btn-sm account-modal-btn" onClick={() => this.handleClose()}>Back</button>
                        </div>
                    </div>
                    </Fade>
                </Modal>
            </div>
        );
    }
}