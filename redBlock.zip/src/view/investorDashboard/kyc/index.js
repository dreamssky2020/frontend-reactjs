import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import '../../../css/investorDashboard/kyc.css'

export class index extends Component {
    componentDidMount(){
        this.props.selectLeftSidebar('kycState');
    }
    render() {
        return (
            <div className="investor-dashboard-container">
                <div className="dashboard-card">
                    <p className="header-title">KYC Verification</p>
                    <p className="description">
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                        At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                    </p>
                    <div className="in-kyc-img-body">
                        <img src={"../../images/file.png"} alt="file png"/>
                    </div>
                    <p className="bottom-description">
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                    </p>
                    <div className="btn-body">
                        <Link to={'/investor-dashboard/kyc-id-verify'} className="link-style">
                            <button>
                                Click here to complete your KCY
                            </button>
                        </Link>
                    </div>
                </div>
            </div>
        )
    }
}

export default index
