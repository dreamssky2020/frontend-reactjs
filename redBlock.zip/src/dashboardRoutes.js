import Account from './view/dashboard/account'
import Assets from './view/dashboard/assets'
import DashboardRedblock from './view/dashboard/assets/DashboardRedblock'
import InvestWhiteList from './view/dashboard/assets/InvestWhiteList'
import Documents from './view/dashboard/assets/Documents'
import Issuance from './view/dashboard/assets/Issuance'
import Distribution from './view/dashboard/assets/Distribution'
import Details from './view/dashboard/assets/Details'
import Banking from './view/dashboard/banking'
import FundingPortal from './view/dashboard/fundingPortial'
import ConfigureNewFundingPortal from './view/dashboard/fundingPortial/ConfigureNewFundingPortal'
import Kyc from './view/dashboard/kyc'
import IdVerify from './view/dashboard/kyc/IdVerify'
import Support from './view/dashboard/support'



const routes = [
  { path: '/dashboard/account', name: 'Account', component: Account },
  { path: '/dashboard/assets', name: 'Assets', component: Assets },
  { path: '/dashboard/redblock', name: 'DashboardRedbloack', component: DashboardRedblock },
  { path: '/dashboard/invest-white-list', name: 'InvestWhiteList', component: InvestWhiteList },
  { path: '/dashboard/documents', name: 'Documents', component: Documents },
  { path: '/dashboard/issuance', name: 'Issuance', component: Issuance },
  { path: '/dashboard/distribution', name: 'Distribution', component: Distribution },
  { path: '/dashboard/details', name: 'Details', component: Details},
  { path: '/dashboard/banking', name: 'Banking', component: Banking },
  { path: '/dashboard/funding-portal', name: 'FundingPortal', component: FundingPortal },
  { path: '/dashboard/configure-new-funding-portal', name: 'ConfigureNewFundingPortal', component: ConfigureNewFundingPortal },
  { path: '/dashboard/kyc', name: 'Kyc', component: Kyc },
  { path: '/dashboard/kyc-id-verify', name: 'IdVerify', component: IdVerify },
  { path: '/dashboard/support', name: 'Support', component: Support },

//   { path: '/users', exact: true,  name: 'Users', component: Users },
//   { path: '/users/:id', exact: true, name: 'User Details', component: User },
];

export default routes;
