import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './css/common.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import BaseBoard from './view/baseBoard';
import HomePage from './view/homepage';
import AboutUsPage from './view/aboutUs';
import StartInvestingPage from './view/startInvestingPage';
import InvestNowPage from './view/InvestNowPage';
import ConfiureFundingPortalPage from './view/configureFundingPortal';
import AssetsDetailPage from './view/assetsDetailPage';
import RaiseCapitalPage from './view/RaiseCapitalPage';
import RegisterPage from './view/registerPage';
import IssuerSignUpPage from './view/registerPage/IssuerSignUpPage';
import InvestorSignUpPage from './view/registerPage/InvestorSignUpPage';
import IssuerLoginPage from './view/registerPage/IssuerLoginPage';
import InvestorLoginPage from './view/registerPage/InvestorLoginPage';

// dashboard
import DashboardPage from './components/dashboard';
import InvestorDashboardPage from './components/investorDashboard';

// Admin account
import AdminDashboardPage from './components/adminDashboard';



export class App extends Component {
  render() {
    return (
      <Router>
          <Switch>
              <Route exact path='/' component={BaseBoard} />
              <Route path='/homepage' component={ HomePage } />
              <Route path='/about-us' component={ AboutUsPage } />
              <Route path='/start-investing' component={ StartInvestingPage } />

              <Route path='/invest-now' component={ InvestNowPage } />
              <Route path='/confiure-funding-portal' component={ ConfiureFundingPortalPage } />
              <Route path='/assets-detail' component={ AssetsDetailPage } />
              <Route path='/raise-capital' component={ RaiseCapitalPage } />
              <Route path='/visitor-register' component={ RegisterPage } />
              <Route path='/issuer-sign-up' component={ IssuerSignUpPage } />
              <Route path='/investor-sign-up' component={ InvestorSignUpPage } />
              <Route path='/investor-log-in' component={ InvestorLoginPage } />
              <Route path='/issuer-log-in' component={ IssuerLoginPage } />
              
              {/******************** dashboard route ***********************/}
              <Route path='/dashboard/' component={ DashboardPage } />
              
              {/****************Investor dashboard route ********************/}
              <Route path='/investor-dashboard/' component={ InvestorDashboardPage } />

              {/****************Admin dashboard route ********************/}
              <Route path='/admin-dashboard/' component={ AdminDashboardPage } />

          </Switch>
      </Router>
    )
  }
}
export default App
