import React, { Component } from 'react'
import { Switch, Route } from 'react-router-dom'

import routes from '../../adminDashboardRoutes';

import Header from './Header'
import LeftSideBar from './LeftSideBar'

export class index extends Component {
    constructor(props){
        super(props);
        this.HeaderRef= React.createRef();
        this.LeftSidebarRef= React.createRef();
    }

    handleLeftSidebar = () => {
        this.HeaderRef.current.closeLeftSidebar();
    }

    selectLeftSidebar = (txt) => {
        this.LeftSidebarRef.current.selectLeftSidebar(txt);
    }


    render() {
        return (
            <div className="dashboard-app">
                <LeftSideBar ref={this.LeftSidebarRef}/>
                <div className="dashboar-main" id="dashboardMain">
                    <Header  ref={this.HeaderRef}/>
                    <div className="dashboard-container">
                        <Switch>
                            {routes.map((route, idx) => {
                                return route.component ? (
                                <Route
                                    key={idx}
                                    path={route.path}
                                    exact={route.exact}
                                    name={route.name}
                                    render={props => (
                                    <route.component {...props} selectLeftSidebar={this.selectLeftSidebar}/>
                                    )} />
                                ) : (null);
                            })}
                        </Switch>
                        <div className="dashboard-mask" id="dashboardMask" onClick={()=>this.handleLeftSidebar()}></div>
                    </div>
                </div>
            </div>
        )
    }
}

export default index
