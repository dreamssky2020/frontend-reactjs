import React, { Component } from 'react'
import Accordion from './Accoridion'

export class JoinStep extends Component {
    render() {
        const { data} = this.props;
        return (
            <div>
               <div className="joinstep-content">
                    <div className="leftpart-title">
                        <div className="step">
                            <p className="mb-0">Step</p>
                            <p className="mb-0">
                                <span className="step-amount"><strong>{data.step}</strong></span>
                                <span className="content-basic-color">/6</span>
                            </p>
                        </div>
                        <div className="stepContent-subTitle">
                            <h5>Sign Up & Join RedBlock</h5>
                        </div>
                    </div>
                    <div className="joinstepcontent-body row">
    {/* left */}
                        <div className=" col-lg-7 joinstepcontent-leftpart">
                            
                            <div className="leftpart-content">
                                <h5>Enter your Name & Email Address to create an user account on Redblock</h5>
                                <div className="accordion-cotent">
                                    <Accordion/>
                                </div>
                            </div>
                        </div>
    {/* right */}
                        <div  className="col-lg-5 ">
                            <div className="joinstepcontent-rightpart">
                                <img src="../../images/chilren-raise.png" alt="children png"/>
                            </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        )
    }
}

export default JoinStep
