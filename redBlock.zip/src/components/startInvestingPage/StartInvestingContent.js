import React, { Component } from 'react'
import JoinStep from './JoinStep'
import JoinStepData from'../../data/joinstepData.json'
import '../../css/raise.css'
import { Link } from 'react-router-dom'

export class Raise extends Component {
    
    constructor(props){
        super(props);
        this.state = {
            steps: [],
        }
    }
    componentDidMount(){
        this.setState({steps: JoinStepData});
    }



    Joinstep(){
        return this.state.steps.map((step, i) => {
           return <JoinStep key={i} data = {step} />
        })     
    }
    render() {
        return (
            <div>
                <div className="content-img-body">
                    <img src="./images/start-investing.png" alt="Rectangle 21" className="about-img" />
                    <div className="text-onimg-body">
                        <h1 className="text-onimg">How to Raise Capital</h1>
                    </div>
                </div>
                <div className="container">
                    <div className="raiseContent">
                        <div className="raise-header">
                            <h2><span className="red-border-left-bg"></span> Learn how to digitize securities and tokenize assets</h2>
                            <p className="raise-header-descrioption">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est.
                            </p>
                        </div> 
                        <div className="JoinStep-body">
                            {this.Joinstep()}
                        </div>
                        <div className="red-sign-up-btn-container">
                            <Link to={'/invest-now'} className="link-style">
                                <input type="button" value="SIGN UP"/>
                            </Link>
                        </div>    
                    </div>
                </div>
            </div>
        )
    }
}

export default Raise