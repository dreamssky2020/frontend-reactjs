import React, { Component } from 'react'
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline'
import Select from 'react-select'
import { Link } from 'react-router-dom'

import Checkbox from '@material-ui/core/Checkbox';
import '../../css/startInvest.css'

const options1 = [
    {value: "Account 1", label: "Account 1"},
    {value: "Account 2", label: "Account 2"},
    {value: "Account 3", label: "Account 3"},
];

const options2 = [
    {value: "Type 1", label: "Type 1"},
    {value: "Type 2", label: "Type 2"},
    {value: "Type 3", label: "Type 3"},
];

const options3 = [
    {value: "United State", label: "United State"},
    {value: "Canada", label: "Canada"},
    {value: "France", label: "France"},
];

const options4 = [
    {value: "VISA", label: "VISA"},
    {value: "Paypal", label: "Paypal"},
    {value: "Bitcoin", label: "Bitcoin"},
];
export class StartInvestContent extends Component {
    render() {
        return (
            <div className="start-invest-container">
                <div className="header-section">
                    <p className="title">You are now Investing in RedCube</p>
                    <p className="content">By investing in RedCube, you are purchasing the assets at $3.14 per unit</p>
                </div>
                <div className="container">
                    <div className="row pt-5 mb-5">
                        <div className="col-lg-8">
                            <h2 className="dark-blue"><strong>1. About You</strong></h2>
                            <div className="flex-align-justify error-content">
                                <div className="kyc-fail-container">
                                    <ErrorOutlineIcon className="error-icon"/>
                                    <h2 className="mb-0 first">Your KYC status:</h2>
                                    <h2 className="mb-0 second"><strong>Fail</strong></h2>
                                </div>
                                <p className="last mb-0">go to your account</p>
                            </div>
                            <h4 className="dark-blue"><strong>Important Information: </strong></h4>
                            <p className="main-p-color pb-2">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                                aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. 
                            </p>
                            <h4 className="dark-blue"><strong>What is mean for you: </strong></h4>
                            <p className="main-p-color pb-2">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                                At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                            </p>



                            {/* sectin  2 */}
                            <h2 className="dark-blue mt-5 pt-5"><strong>2. Your Investment</strong></h2>
                            <div className="section2-input-box-container">
                                <h5 className="mb-0 dark-blue pr-4"><strong>Investment Amount: </strong></h5>
                                <input type="text" placeholder="USD"></input>
                            </div>
                            <p className="main-p-color pt-3">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                                sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                            </p>



                            {/* sectin  3 */}
                            <h2 className="dark-blue mt-5 pt-5"><strong>3. Investor Account</strong></h2>
                            <div className="investor-account-body">
                                <div className="account-item-one">
                                    <div className="left-label">Account Name</div>
                                    <Select options={options1} placeholder="Add New Account" className="account-select"/>
                                </div>
                                <div className="account-item-one">
                                    <div className="left-label">Account Type</div>
                                    <input placeholder="Trust Account" className="trust-account-input"/>
                                </div>
                                <div className="account-item-one">
                                    <div className="left-label">Legal Name</div>
                                    <Select options={options2} placeholder="My Entry Name" className="account-select"/>
                                </div>
                                <div className="account-item-one">
                                    <div className="left-label">Registration Country</div>
                                    <Select options={options3} placeholder="e.g. United States" className="account-select"/>
                                </div>
                                <p className="mt-2 pl-3">
                                    <span style={{color: "#D74B4B"}} className="pr-2"><strong>Important:</strong></span>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna.
                                </p>
                                <p className="mt-5">
                                    Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna.
                                </p>
                                <div className="checkbox-icon-body">
                                    <div className="left-label">
                                        <Checkbox className="pink-border-checkbox" />
                                        <p className="mb-0">Yes, I confirm this true</p>
                                    </div>
                                    <div className="right-label">
                                        <Checkbox className="pink-border-checkbox" />
                                        <p className="mb-0">Yes, I confirm this true</p>
                                    </div>
                                </div>
                                <div className="third-section-bottom">
                                    <Checkbox className="pink-border-checkbox lg-checkbox" />
                                    <p className="dark-blue">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                        At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                                        sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                                    </p>
                                </div>
                            </div>


                            {/* sectin  4 */}
                            <h2 className="dark-blue mt-5 pt-5"><strong>4. Payment Method</strong></h2>
                            <div className="investor-account-body">
                                <div className="account-item-one">
                                    <div className="left-label">Payment Method</div>
                                    <Select options={options4} placeholder="Add Wire Transfer" className="payment-select account-select"/>
                                </div>
                                <div className="account-item-one">
                                    <div className="left-label">Bank Name</div>
                                    <input placeholder="e.g. Chese" className="account-input"/>
                                </div>
                                <div className="account-item-one">
                                    <div className="left-label">Bank Account Number</div>
                                    <input placeholder="e.g. 1235698712" className="account-input"/>
                                </div>
                                <div className="account-item-one">
                                    <div className="left-label">Country of Bank</div>
                                    <Select options={options3} placeholder="e.g. United States" className="trust-account-select account-select"/>
                                </div>
                               
                                <p className="mt-2 main-p-color">
                                    Is this Bank Account held in the name Zung li?
                                </p>

                                <div className="checkbox-icon-body">
                                    <div className="left-label">
                                        <Checkbox className="pink-border-checkbox" />
                                        <p className="mb-0">Yes</p>
                                    </div>
                                    <div className="right-label">
                                        <Checkbox className="pink-border-checkbox" />
                                        <p className="mb-0">No</p>
                                    </div>
                                </div>
                            </div>

                            
                            {/* sectin  5 */}
                            <h2 className="dark-blue mt-5 pt-5"><strong>5. Review Your Investment</strong></h2>
                            <div className="section5-container">
                                <h5 style={{color: "#D74B4B"}} className="pt-2 pb-2">
                                        Please Acknowledge that you have read and agreed to the following statements by clicking all the text below
                                </h5>
                                <div className="third-section-bottom">
                                    <Checkbox className="pink-border-checkbox lg-checkbox" />
                                    <p className="main-p-color">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                        At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                                        sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                                    </p>
                                </div>
                                <div className="third-section-bottom">
                                    <Checkbox className="pink-border-checkbox lg-checkbox" />
                                    <p className="main-p-color">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                    </p>
                                </div>
                                <div className="third-section-bottom">
                                    <Checkbox className="pink-border-checkbox lg-checkbox" />
                                    <p className="main-p-color">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                                        sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus.
                                    </p>
                                </div>
                                <div className="third-section-bottom">
                                    <Checkbox className="pink-border-checkbox lg-checkbox" />
                                    <p className="main-p-color">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                                        sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.orem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                                        Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy
                                    </p>
                                </div>
                                <div className="third-section-bottom">
                                    <Checkbox className="pink-border-checkbox lg-checkbox" />
                                    <p className="main-p-color">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                                        sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.orem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                                        Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy
                                    </p>
                                </div>
                            </div>
                            <div className="submit-invest-btn-body">
                                <Link to={'/confiure-funding-portal'} className="link-style">
                                    <button>Submit Your Investment</button>
                                </Link>
                            </div>

                        </div>


                        <div className="col-lg-4">
                            <div className="start-invest-price-card">
                                <div className="flex-align-justify pb-1">
                                    <h5 className="mb-0 dark-blue">Investment amount:</h5>
                                    <h5 className="mb-0 dark-blue"><strong>US $1000.00</strong></h5>
                                </div>
                                <div className="flex-align-justify pb-1">
                                    <h5 className="mb-0 dark-blue">Transection Fees:</h5>
                                    <h5 className="mb-0 dark-blue"><strong>US $20.00</strong></h5>
                                </div>
                                <div className="border-line-div"></div>
                                <div className="flex-align-justify pb-1">
                                    <h5 className="mb-0 dark-blue">Total Funded:</h5>
                                    <h5 className="mb-0 dark-blue"><strong>US $1020.00</strong></h5>
                                </div>
                                <div className="border-line-div"></div>
                                <p className="pt-1 pb-1">
                                    Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                                    sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                                </p>
                                <p className="pb-0 mb-0">
                                    Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                    At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default StartInvestContent
