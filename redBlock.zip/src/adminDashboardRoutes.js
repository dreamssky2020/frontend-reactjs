import Account from './view/adminDashboard/account';
import Issuer from './view/adminDashboard/issuer';
import IssuerRedblock from './view/adminDashboard/issuer/redblock';






const routes = [
  { path: '/admin-dashboard/account', name: 'adminAccount', component: Account },
  { path: '/admin-dashboard/issuer', name: 'adminIssuer', component: Issuer },
  { path: '/admin-dashboard/issuer-redblock', name: 'adminIssuer', component: IssuerRedblock },


];

export default routes;
